
  # Ravar Imoveis

  This is a code bundle for Ravar Imoveis. The original project is available at https://www.figma.com/design/WfMVHB3CDTDgZWFbjie7za/Ravar-Imoveis.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  